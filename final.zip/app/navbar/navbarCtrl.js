app.controller("navbarCtrl", function($scope) {
    $scope.isLoggedIn = function()
    {
        return false;
    }
}); 