
app.directive("managejobsNavbar", function () {
    return {
        templateUrl: "app/navbar/navbar.html",
        controller: "navbarCtrl"
    }
})