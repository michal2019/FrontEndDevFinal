app.controller("loginCtrl", function($scope) { 
}); 